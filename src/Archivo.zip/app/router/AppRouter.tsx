import { Route, Routes } from 'react-router-dom';

import { PlatformLayout } from '../../layouts/PlatformLayout';
import { LandingPage } from '../../pages/Landing';
import { LoginPage } from '../../pages/Login';
import { PlatformDashboardPage } from '../../pages/PlatformDashboard';

export const AppRouter = () => {
  return (
    <Routes>
      {/* Public */}
      <Route
        path="/"
        element={<LandingPage />}
      />

      <Route
        path="/login"
        element={<LoginPage />}
      />

      {/* Platform */}
      <Route
        path="/platform"
        element={<PlatformLayout />}
      >
        <Route
          path="dashboard"
          element={<PlatformDashboardPage />}
        />
      </Route>
    </Routes>
  );
};