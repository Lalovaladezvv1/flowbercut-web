import { useState } from 'react';
import {
  Box,
  alpha,
} from '@mui/material';
import { Outlet } from 'react-router-dom';
import { AnimatedBackground } from '../../components/organisms/AnimatedBackground';
import {
  PlatformHeader,
} from '../../components/organisms/PlatformHeader';
import {
  DRAWER_WIDTH,
  PlatformSidebar,
} from '../../components/organisms/PlatformSidebar';

export const PlatformLayout = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <Box
      sx={{
        minHeight: '100dvh',
        background: '#050507',
        color: '#F5F5F7',
      }}
    >
      <AnimatedBackground />

      <PlatformSidebar
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />

      <Box
        sx={{
          position: 'relative',
          zIndex: 1,
          minHeight: '100dvh',
          ml: {
            xs: 0,
            md: `${DRAWER_WIDTH}px`,
          },
        }}
      >
        <PlatformHeader
          onMenuClick={() => setMobileOpen(true)}
        />

        <Box
          component="main"
          sx={{
            minHeight: 'calc(100dvh - 76px)',
            p: {
              xs: 2,
              sm: 3,
              lg: 4,
            },
            background: `
              linear-gradient(
                180deg,
                ${alpha('#050507', 0.35)} 0%,
                ${alpha('#050507', 0.72)} 100%
              )
            `,
          }}
        >
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};