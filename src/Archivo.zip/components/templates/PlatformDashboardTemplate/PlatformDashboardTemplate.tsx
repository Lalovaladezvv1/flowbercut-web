import {
  AttachMoneyRounded,
  BusinessRounded,
  PeopleRounded,
  StorefrontRounded,
} from '@mui/icons-material';
import {
  Box,
  Typography,
  alpha,
} from '@mui/material';

import { GradientButton } from '../../atoms/GradientButton';
import { PlatformGrowthChart } from '../../organisms/PlatformGrowthChart';
import { PlatformKpiCard } from '../../organisms/PlatformKpiCard';
import { RecentTenants } from '../../organisms/RecentTenants';

export interface PlatformDashboardTemplateProps {
  onManageTenants: () => void;
}

export const PlatformDashboardTemplate = ({
  onManageTenants,
}: PlatformDashboardTemplateProps) => {
  return (
    <Box
      sx={{
        width: '100%',
        maxWidth: 1500,
        mx: 'auto',
      }}
    >
      {/* Header */}
      <Box
        sx={{
          mb: {
            xs: 3,
            md: 4,
          },
          display: 'flex',
          alignItems: {
            xs: 'flex-start',
            md: 'center',
          },
          justifyContent: 'space-between',
          flexDirection: {
            xs: 'column',
            md: 'row',
          },
          gap: 2.5,
        }}
      >
        <Box>
          <Typography
            component="h1"
            sx={{
              color: '#F5F5F7',
              fontSize: {
                xs: '1.65rem',
                sm: '2rem',
                lg: '2.25rem',
              },
              fontWeight: 700,
              lineHeight: 1.1,
              letterSpacing: '-0.045em',
            }}
          >
            Buenos días, Eduardo
          </Typography>

          <Typography
            sx={{
              mt: 0.9,
              color: alpha('#F5F5F7', 0.45),
              fontSize: {
                xs: '0.82rem',
                sm: '0.9rem',
              },
            }}
          >
            Esto es lo que está pasando en FLOWBERCUT.
          </Typography>
        </Box>

        <GradientButton
          onClick={onManageTenants}
        >
          Administrar barberías
        </GradientButton>
      </Box>

      {/* KPIs */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, minmax(0, 1fr))',
            lg: 'repeat(4, minmax(0, 1fr))',
          },
          gap: 2,
        }}
      >
        <PlatformKpiCard
          title="Barberías"
          value="12"
          description="Registradas en plataforma"
          icon={<BusinessRounded fontSize="small" />}
          accent="#0A84FF"
        />

        <PlatformKpiCard
          title="Barberías activas"
          value="10"
          description="Actualmente operativas"
          icon={<StorefrontRounded fontSize="small" />}
          accent="#64D2FF"
        />

        <PlatformKpiCard
          title="Usuarios"
          value="24"
          description="Usuarios administradores"
          icon={<PeopleRounded fontSize="small" />}
          accent="#BF5AF2"
        />

        <PlatformKpiCard
          title="MRR"
          value="$1,990"
          description="Ingreso mensual recurrente"
          icon={<AttachMoneyRounded fontSize="small" />}
          accent="#FF375F"
        />
      </Box>

      {/* Main content */}
      <Box
        sx={{
          mt: 2,
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            xl: 'minmax(0, 1.65fr) minmax(320px, 0.85fr)',
          },
          gap: 2,
        }}
      >
        <PlatformGrowthChart />

        {/* Platform status */}
        <Box
          sx={{
            minHeight: 330,
            p: {
              xs: 2.5,
              sm: 3,
            },
            borderRadius: 3,
            background:
              'linear-gradient(145deg, rgba(24,24,30,0.78), rgba(12,12,16,0.88))',
            border: '1px solid rgba(255,255,255,0.08)',
            boxShadow:
              '0 20px 60px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.035)',
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
          }}
        >
          <Typography
            sx={{
              color: '#F5F5F7',
              fontSize: '1rem',
              fontWeight: 650,
              letterSpacing: '-0.02em',
            }}
          >
            Estado de plataforma
          </Typography>

          <Typography
            sx={{
              mt: 0.5,
              color: alpha('#F5F5F7', 0.4),
              fontSize: '0.74rem',
            }}
          >
            Resumen actual
          </Typography>

          <Box
            sx={{
              mt: 3,
              display: 'flex',
              flexDirection: 'column',
              gap: 1.25,
            }}
          >
            <StatusRow
              label="Barberías activas"
              value="10"
              accent="#64D2FF"
            />

            <StatusRow
              label="Barberías inactivas"
              value="2"
              accent="#FF375F"
            />

            <StatusRow
              label="Suscripciones activas"
              value="10"
              accent="#BF5AF2"
            />
          </Box>

          <Box
            sx={{
              mt: 3,
              p: 1.75,
              borderRadius: 2.5,
              backgroundColor: alpha('#64D2FF', 0.045),
              border: `1px solid ${alpha('#64D2FF', 0.1)}`,
            }}
          >
            <Typography
              sx={{
                color: '#64D2FF',
                fontSize: '0.75rem',
                fontWeight: 600,
              }}
            >
              Plataforma operativa
            </Typography>

            <Typography
              sx={{
                mt: 0.45,
                color: alpha('#F5F5F7', 0.4),
                fontSize: '0.68rem',
                lineHeight: 1.5,
              }}
            >
              Los datos mostrados serán conectados posteriormente con la API.
            </Typography>
          </Box>
        </Box>
      </Box>

      {/* Recent tenants */}
      <Box sx={{ mt: 2 }}>
        <RecentTenants />
      </Box>
    </Box>
  );
};

interface StatusRowProps {
  label: string;
  value: string;
  accent: string;
}

const StatusRow = ({
  label,
  value,
  accent,
}: StatusRowProps) => {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 1.5,
        py: 1.35,
        borderRadius: 2,
        backgroundColor: alpha('#FFFFFF', 0.025),
        border: '1px solid rgba(255,255,255,0.05)',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1,
        }}
      >
        <Box
          sx={{
            width: 7,
            height: 7,
            borderRadius: '50%',
            backgroundColor: accent,
            boxShadow: `0 0 10px ${alpha(accent, 0.5)}`,
          }}
        />

        <Typography
          sx={{
            color: alpha('#F5F5F7', 0.58),
            fontSize: '0.75rem',
          }}
        >
          {label}
        </Typography>
      </Box>

      <Typography
        sx={{
          color: '#F5F5F7',
          fontSize: '0.82rem',
          fontWeight: 650,
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};