import { Box, Typography, alpha } from '@mui/material';

import type { PlatformKpiCardProps } from './PlatformKpiCard.types';

export const PlatformKpiCard = ({
  title,
  value,
  description,
  icon,
  accent,
}: PlatformKpiCardProps) => {
  return (
    <Box
      sx={{
        position: 'relative',
        height: '100%',
        minHeight: 156,
        p: {
          xs: 2.25,
          sm: 2.5,
        },
        overflow: 'hidden',
        borderRadius: 3,
        background:
          'linear-gradient(145deg, rgba(24,24,30,0.78), rgba(12,12,16,0.88))',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow:
          '0 20px 60px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.035)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
      }}
    >
      {/* Accent glow */}
      <Box
        sx={{
          position: 'absolute',
          top: -60,
          right: -50,
          width: 150,
          height: 150,
          borderRadius: '50%',
          background: alpha(accent, 0.1),
          filter: 'blur(35px)',
          pointerEvents: 'none',
        }}
      />

      <Box
        sx={{
          position: 'relative',
          zIndex: 1,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Typography
          sx={{
            color: alpha('#F5F5F7', 0.48),
            fontSize: '0.76rem',
            fontWeight: 600,
            letterSpacing: '0.01em',
          }}
        >
          {title}
        </Typography>

        <Box
          sx={{
            width: 38,
            height: 38,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 2,
            color: accent,
            backgroundColor: alpha(accent, 0.08),
            border: `1px solid ${alpha(accent, 0.15)}`,
          }}
        >
          {icon}
        </Box>
      </Box>

      <Typography
        sx={{
          position: 'relative',
          zIndex: 1,
          mt: 2.5,
          color: '#F5F5F7',
          fontSize: {
            xs: '1.75rem',
            sm: '2rem',
          },
          fontWeight: 700,
          lineHeight: 1,
          letterSpacing: '-0.04em',
        }}
      >
        {value}
      </Typography>

      <Typography
        sx={{
          position: 'relative',
          zIndex: 1,
          mt: 1,
          color: alpha('#F5F5F7', 0.38),
          fontSize: '0.72rem',
        }}
      >
        {description}
      </Typography>
    </Box>
  );
};