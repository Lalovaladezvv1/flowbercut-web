import { TrendingUpRounded } from '@mui/icons-material';
import {
  Box,
  Typography,
  alpha,
} from '@mui/material';

export const PlatformGrowthChart = () => {
  return (
    <Box
      sx={{
        height: '100%',
        minHeight: 330,
        p: {
          xs: 2.5,
          sm: 3,
        },
        borderRadius: 3,
        background:
          'linear-gradient(145deg, rgba(24,24,30,0.78), rgba(12,12,16,0.88))',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow:
          '0 20px 60px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.035)',
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <Box>
          <Typography
            sx={{
              color: '#F5F5F7',
              fontSize: '1rem',
              fontWeight: 650,
              letterSpacing: '-0.02em',
            }}
          >
            Crecimiento
          </Typography>

          <Typography
            sx={{
              mt: 0.5,
              color: alpha('#F5F5F7', 0.4),
              fontSize: '0.74rem',
            }}
          >
            Evolución de barberías y suscripciones
          </Typography>
        </Box>

        <Box
          sx={{
            width: 38,
            height: 38,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: 2,
            color: '#64D2FF',
            backgroundColor: alpha('#64D2FF', 0.07),
            border: `1px solid ${alpha('#64D2FF', 0.14)}`,
          }}
        >
          <TrendingUpRounded fontSize="small" />
        </Box>
      </Box>

      <Box
        sx={{
          height: 225,
          mt: 3,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 2.5,
          background:
            'linear-gradient(180deg, rgba(255,255,255,0.025), rgba(255,255,255,0.01))',
          border: '1px dashed rgba(255,255,255,0.08)',
        }}
      >
        <Box sx={{ textAlign: 'center', px: 3 }}>
          <Typography
            sx={{
              color: alpha('#F5F5F7', 0.52),
              fontSize: '0.82rem',
              fontWeight: 500,
            }}
          >
            Las métricas aparecerán aquí
          </Typography>

          <Typography
            sx={{
              mt: 0.6,
              color: alpha('#F5F5F7', 0.28),
              fontSize: '0.7rem',
            }}
          >
            Conectaremos esta sección con la API de plataforma.
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};